import"./src-BH-TyZbA.js";import"./chunk-DU6HZSFF-CF3OK3MZ.js";import{n as e}from"./chunk-Y2CYZVJY-DsF7k-Jl.js";import"./chunk-75Z2AOVW-EXNbuzun.js";import"./chunk-P2QGCYS3-E4AByfsD.js";import"./chunk-PWAF6VOD-DaoPxZAa.js";import"./chunk-GMAD6QVW-2yfGg28o.js";import"./chunk-4HAMMTFA-EgoP78tp.js";import"./chunk-GVQU2GXP-C_VeaX4U.js";import"./index-D3vj8REa.js";import"./chunk-F27PBJKO-G71ylWJa.js";import"./chunk-XXDRQBXY-DFBUG-OT.js";import"./chunk-POPQ4Y6H-Bisbc2-3.js";import{r as t,t as n}from"./chunk-SHT3W25Y-DarPToto.js";var r=n({defaultLayout:`swimlane`,styles:e(e=>`${t(e)}
  .swimlane.cluster rect {
    stroke: ${e.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};